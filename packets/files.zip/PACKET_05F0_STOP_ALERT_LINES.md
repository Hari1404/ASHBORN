# PACKET 05F0: THE LINES OF THE STOP ALERT (53 LINES IN EIGHT BANKS, THE MARKS FOR KEYWORD EFFECTS, THE CHOICE OF A LINE; NO SCREEN CHANGE)

## RULES FOR THE AGENT (read first)
- You decide NOTHING. Do exactly the steps below, in order.
- This packet runs AFTER Packet 05E2. Step 0 checks that it is in place and that the four files this packet creates do not exist yet. If not: **STOP**.
- Create ONLY these four files, each with exactly the block written in its step: `src/lib/lineMarkup.ts`, `src/lib/stopAlertLines.ts`, `src/lib/lineMarkup.test.ts`, `src/lib/stopAlertLines.test.ts`. Edit ONLY these three map files: `CODE_MAP.md`, `CONNECTIONS.md`, `PROGRESS.md`. Change NO other file. No screen, no css, no component and no hook is touched by this packet: nothing imports the new files yet.
- Do NOT create any helper script, `.ps1` file, note or temp file anywhere. Write the four new files with your file-writing tool (put exactly the block in the file, nothing added, nothing left out, no changed quotes). Run every command directly in the terminal.
- `src/components/AppMenu.tsx` and `src/menu.css` may have changes that are NOT part of this packet. Do not open, edit, stage, revert or commit them. Other untracked files (the `packets` files, `run_*.ps1`) are also not part of this packet: leave them alone.
- `src/lib/timerMaths.ts` is read by the new files and is NOT changed. The library components (`SideRays.tsx`, `MetaBalls.tsx`, `CrystalizedBall.tsx`, `HoldButton.tsx`, `BlurText.tsx`) are never opened for editing.
- Do not run `npm audit fix`, `npm update`, `npm uninstall`, `npm install`, or any other install. This packet needs none. Do not run `npm run lint`.
- NEVER open, print, copy, edit or delete the file `.env` or the file named `-files .env`. NEVER run `git add .` or `git add -A` in this packet. Only the exact `git add` line in Step 9 is allowed.
- Every "find and replace" below says where to look. The old text or the heading must be found EXACTLY ONCE. If it is found zero times or more than once: **STOP** and report which one. Do not guess. Ignore the line ending (a trailing carriage return) when you compare lines, and keep the line endings of a file as they are (a new line gets the same line ending as the line next to it).
- If any step fails, asks for a license key, a login, a payment, or asks any question not covered here: **STOP and report the exact message. Do not try to fix it yourself.**
- Your final reply MUST contain the raw outputs listed in WHEN DONE. A reply that only says PASS is a FAILED packet.

## WHAT THIS DOES
It writes the words of the stop alert, the thing the owner sees after holding "Hold to end session", and the small machinery that picks and cuts up a line. It does NOT show anything yet: no screen, no button, no database call changes, so the Pro Timer looks and works exactly as after Packet 05E2. The alert itself comes in later packets (the hook with the pause-first flow, the text component that draws the effects, the alert screen).

**The lines.** 53 lines in eight banks, chosen by the length of the session: under 60 seconds (not saved), 1 to 4, 5 to 9, 10 to 19, 20 to 29, 30 to 44, 45 to 89 and 90 minutes and more. The banks are named by their minutes (`under1`, `from1`, `from5`, `from10`, `from20`, `from30`, `from45`, `from90`) and never by the words solid, deep or flow, because the cut-offs of the banks are not the cut-offs of the quality labels on the screen. The banks follow the cut-offs of `timerMaths.ts`: five of the seven edges are imported from there (60 seconds, 10, 30, 45 and 90 minutes), never written again. The wording follows the owner's review: the blunt tone stays; a "real session" is 45 minutes; no line says a saved session counted for nothing; no line says the time of day, how many sessions came before, or "unbroken"; no number is written that the session did not have.

**The slots.** `{n}` is the whole minutes of the session (rounded down), `{time}` is the same with its unit ("8 minutes", "1 minute"), `{left}` is the minutes still missing to 45 (rounded up, never below 1). They are filled from the real seconds, so a line can never say "7 minutes away" to a person who was 3 minutes away.

**The keyword marks.** Every line marks one to three keywords like this: `You [heat:earn] it.` The word `earn` will get the effect `heat` when the text component of a later packet shows the line. Six effects exist: `glow` (the important or true thing), `heat` (effort and earning), `shake` (failure and flinching), `strike` (the fake thing), `ghost` (nothing, fading), `rise` (growing and stacking). A mark that is wrong (an unknown name, a bracket not closed) never breaks anything: it stays in the text as it was, so a typo is seen on the screen instead of crashing the alert, and the tests read all 53 lines and fail on such a typo.

**The choice of a line.** Every bank is shown in a shuffled order and no line comes twice before all lines of the bank were shown; a new round never starts with the line that ended the old one. The random numbers are handed in, so the tests can fix them.

New: tags `AB:TIMER.LINE-MARKUP` and `AB:TIMER.ALERT-LINES`, connections C41 (the lines are tied to the cut-offs and to GO BACK IN) and C42 (the marks and the six effect names are tied to the text component of the later packet), and one sentence added to C27 so that whoever changes a cut-off is sent to C41. 38 new tests: 17 in `lineMarkup.test.ts`, 21 in `stopAlertLines.test.ts`. The tests pin: where each bank starts to the second; that the banks without GO BACK IN are exactly the sessions that cannot go back in (every second up to 100 minutes); that every written number is a cut-off that is true for its bank; that "flow" appears only from 90 minutes; that no line says what the app cannot know; that all slots are filled and all brackets gone at the first and last second of every bank; the shuffle (every line once per round, no repeat across rounds for 200 different series of random numbers).

---

## STEP 0: Check the starting state
Check that these exist: `CODE_MAP.md`, `CONNECTIONS.md`, `PROGRESS.md`, `scripts/check-tags.mjs`, `package.json`, `src/lib/timerMaths.ts`, `src/lib/timerMaths.test.ts`, `src/components/SideRays.tsx`, `src/lib/backgroundLook.ts`. If any is missing: **STOP** and report which. If `src/lib/backgroundLook.ts` is missing, Packet 05E2 has not been run: say exactly that in your report.

Check that these four files do NOT exist: `src/lib/lineMarkup.ts`, `src/lib/stopAlertLines.ts`, `src/lib/lineMarkup.test.ts`, `src/lib/stopAlertLines.test.ts`. If one exists: **STOP** and report "<path> already exists."

Run `node scripts/check-tags.mjs`. It must print exactly (these are the numbers after Packet 05E2):
```
TAGS OK: 26 tags, 46 places
CONNECTIONS OK: 40 connections, 236 anchors, 36 classes, 2 css variables, 2 label links
```
If it prints anything else: **STOP** and report the COMPLETE output.

Run `git status --short`. Lines that start with `??` are fine. A line for a changed tracked file is fine ONLY for these two paths: `src/components/AppMenu.tsx`, `src/menu.css`.
- If `CODE_MAP.md`, `CONNECTIONS.md` or `PROGRESS.md` shows as changed (an `M` in either column): **STOP** and report the COMPLETE output of `git status --short` and the COMPLETE output of `git diff -- <that file>`. Do not commit, restore or edit anything.
- If ANY other tracked file is changed: **STOP** and report the COMPLETE output of `git status --short`.

Run `git log --oneline -20`. One of the twenty lines must contain the text `Packet 05E2`. If none does: **STOP** and report the COMPLETE output (Packet 05E2 was not committed).

Run:
```
npm test
```
It must finish with a line `Test Files  10 passed (10)` and a line `Tests  565 passed (565)`. If not: **STOP** and report the last 12 lines of the output.

Run this ONE command (it prints the lines of `timerMaths.ts` that the new files depend on):
```
Select-String -Path src/lib/timerMaths.ts -Pattern "^export const (MIN_SESSION_SECONDS|SOLID_FROM_SECONDS|DEEP_FROM_SECONDS|FLOW_FROM_SECONDS|GO_BACK_IN_LIMIT_SECONDS) = |^export function (wholeSeconds|canGoBackIn)\(" | ForEach-Object { $_.Line }
```
It must print exactly these 7 lines, in this order:
```
export const MIN_SESSION_SECONDS = 60
export const SOLID_FROM_SECONDS = 600
export const DEEP_FROM_SECONDS = 1800
export const FLOW_FROM_SECONDS = 5400
export const GO_BACK_IN_LIMIT_SECONDS = 2700
export function wholeSeconds(value: number): number {
export function canGoBackIn(seconds: number): boolean {
```
If it prints anything else: **STOP** and report the RAW output. The lines of this packet are written for exactly these cut-offs.

Then run these read-only commands. Do NOT stop on their results and do NOT fix anything. Copy the RAW output of each under its number (write EMPTY if nothing prints):
1. `git status --short`
2. `git log --oneline -5`
3. `git ls-files | Select-String -Pattern "\.env"`
4. `node -v`
5. This ONE command (information only: the planner wants the fingerprint of `timerMaths.ts` for the record):
```
foreach ($f in @("src/lib/timerMaths.ts")) { $t = (Get-Content -Raw -Encoding UTF8 $f).Replace("`r`n","`n").TrimEnd(); $h = [System.BitConverter]::ToString([System.Security.Cryptography.SHA256]::Create().ComputeHash([System.Text.Encoding]::UTF8.GetBytes($t))).Replace("-","").ToLower(); "$f $h" }
```

## STEP 1: Create `src/lib/lineMarkup.ts`
Create the file `src/lib/lineMarkup.ts` with exactly this content:

```ts
import { GO_BACK_IN_LIMIT_SECONDS, wholeSeconds } from "@/lib/timerMaths"

// AB:TIMER.LINE-MARKUP:START
// How a line of text for the Pro Timer is written, and how it is cut into pieces for the screen. Pure functions: no screen, no clock, no randomness.
// A line is plain text with two kinds of marks (see CONNECTIONS.md C42):
//   {n}, {time}, {left}  are slots. fillSlots puts the real numbers of the session in them (a line must never say a number the session did not have).
//   [effect:words]       marks the words that get an effect while the line is shown, for example "You [heat:earn] it." The six effect names are in EFFECTS.
// What the effects mean (the css of the text component, a later packet, draws them):
//   glow = the important or true thing, heat = effort and earning, shake = failure and flinching, strike = the fake thing, ghost = nothing and fading, rise = growing and stacking.
// parseMarkup never throws. A mark it does not understand (an unknown effect name, a bracket that is not closed) stays in the text as it was, so a typo in a line shows up on the screen instead of breaking the alert. The tests of stopAlertLines.test.ts check every line.
// The automated tests are in src/lib/lineMarkup.test.ts. Run them with: npm test

export const EFFECTS = ["glow", "heat", "shake", "strike", "ghost", "rise"] as const
export type Effect = (typeof EFFECTS)[number]

// A piece of a line: its text and the effect of that piece (null for plain text).
export type Fragment = { text: string; effect: Effect | null }
// One word as the screen shows it: the pieces that touch each other without a space, for example the word "earn" with its effect and the "." after it.
export type Word = readonly Fragment[]

const MARK = /\[([a-z]+):([^[\]]+)\]/g

function isEffect(name: string): name is Effect {
  return (EFFECTS as readonly string[]).includes(name)
}

// 1 -> "1 minute", every other number -> "8 minutes" (0 -> "0 minutes").
export function minutesText(minutes: number): string {
  return minutes === 1 ? "1 minute" : minutes + " minutes"
}

// {n}: whole minutes of the session, rounded down, the number only.
// {time}: the same with its unit ("8 minutes").
// {left}: the minutes still missing to the end of GO BACK IN (45 minutes), rounded UP, with its unit, never less than 1 ("7 minutes"). Only lines of sessions shorter than that use it.
export function fillSlots(line: string, seconds: number): string {
  const s = wholeSeconds(seconds)
  const minutes = Math.floor(s / 60)
  const left = Math.max(1, Math.ceil((GO_BACK_IN_LIMIT_SECONDS - s) / 60))
  return line
    .replaceAll("{n}", String(minutes))
    .replaceAll("{time}", minutesText(minutes))
    .replaceAll("{left}", minutesText(left))
}

// Cuts a line into pieces: plain text and the marked words with their effect.
export function parseMarkup(line: string): Fragment[] {
  const out: Fragment[] = []
  let last = 0
  for (const m of line.matchAll(MARK)) {
    const at = m.index ?? 0
    if (at > last) out.push({ text: line.slice(last, at), effect: null })
    out.push({ text: m[2], effect: isEffect(m[1]) ? m[1] : null })
    last = at + m[0].length
  }
  if (last < line.length) out.push({ text: line.slice(last), effect: null })
  return out
}

// Groups the pieces into words. A space ends a word, any number of spaces count as one, and spaces at the start and at the end are dropped. A marked piece with several words ("real session") becomes one word per word, each with the effect.
export function toWords(fragments: readonly Fragment[]): Word[] {
  const words: Fragment[][] = []
  let current: Fragment[] = []
  for (const fragment of fragments) {
    for (const part of fragment.text.split(/(\s+)/)) {
      if (part === "") continue
      if (/^\s+$/.test(part)) {
        if (current.length > 0) {
          words.push(current)
          current = []
        }
      } else {
        current.push({ text: part, effect: fragment.effect })
      }
    }
  }
  if (current.length > 0) words.push(current)
  return words
}

// The line as plain text, without the marks (slots are not filled here).
export function plainText(line: string): string {
  return parseMarkup(line)
    .map((fragment) => fragment.text)
    .join("")
}
// AB:TIMER.LINE-MARKUP:END
```

## STEP 2: Create `src/lib/stopAlertLines.ts`
Create the file `src/lib/stopAlertLines.ts` with exactly this content:

```ts
import { fillSlots } from "@/lib/lineMarkup"
import {
  DEEP_FROM_SECONDS,
  FLOW_FROM_SECONDS,
  GO_BACK_IN_LIMIT_SECONDS,
  MIN_SESSION_SECONDS,
  SOLID_FROM_SECONDS,
  wholeSeconds,
} from "@/lib/timerMaths"

// AB:TIMER.ALERT-LINES:START
// The lines the stop alert shows after Hold to end session, and the choice of one of them. Pure functions: no screen, no clock of its own (the random numbers are handed in, so the tests can fix them).
// The lines are grouped in banks by the length of the session. The banks are named by their minutes (from5 = 5 minutes and more), never by the quality words of the timer, because the cut-offs are not the same (see CONNECTIONS.md C41).
// Every line uses the marks of lineMarkup.ts (see CONNECTIONS.md C42): {n}, {time} and {left} are filled with the real numbers of the session, and [effect:words] marks the keywords that get an effect when the line is shown.
// Rules that every line follows (the tests of stopAlertLines.test.ts check them): a number written in a line is a cut-off and is true for the bank it sits in; "flow" is only said from 90 minutes; a line never says the time of day, how many sessions there were before, or that a saved session counted for nothing; every line has one to three marked keywords.
// The automated tests are in src/lib/stopAlertLines.test.ts. Run them with: npm test

export type BankId = "under1" | "from1" | "from5" | "from10" | "from20" | "from30" | "from45" | "from90"

// From the shortest session to the longest.
export const BANK_IDS: readonly BankId[] = ["under1", "from1", "from5", "from10", "from20", "from30", "from45", "from90"]

// The seconds from which each bank is used, from the longest bank to the shortest. Five of the edges are cut-offs of the timer and are imported, never written again (C41); the banks from5 and from20 have edges of their own (5 and 20 minutes).
const FROM_SECONDS: readonly (readonly [BankId, number])[] = [
  ["from90", FLOW_FROM_SECONDS],
  ["from45", GO_BACK_IN_LIMIT_SECONDS],
  ["from30", DEEP_FROM_SECONDS],
  ["from20", 20 * 60],
  ["from10", SOLID_FROM_SECONDS],
  ["from5", 5 * 60],
  ["from1", MIN_SESSION_SECONDS],
]

// The bank of a session of this length. Under 60 seconds the timer does not save the session, and that has its own bank (under1).
export function bankIdFor(seconds: number): BankId {
  const s = wholeSeconds(seconds)
  for (const [id, from] of FROM_SECONDS) {
    if (s >= from) return id
  }
  return "under1"
}

export const STOP_ALERT_BANKS: Readonly<Record<BankId, readonly string[]>> = {
  // Under 60 seconds: not saved. GO BACK IN is offered.
  under1: [
    "Under a minute, so nothing was saved. That wasn't a session. That was a [shake:tap].",
    "Not even one minute. The timer won't save it, and your future self won't [ghost:remember it].",
    "A minute is the minimum. You didn't reach it. [heat:Go back in], or admit you only came to look.",
    "Nothing to save. You pressed start and [shake:lost your nerve]. [heat:Go back in] and make it count.",
  ],
  // 1 to 4 minutes.
  from1: [
    "You sat down, opened the timer, felt like you did something, and left. That's not work. That's [strike:cosplay].",
    "A [shake:microwave] runs longer than your [ghost:focus span] just did. Think about that.",
    "You spent more time [shake:deciding] to start than you spent actually working. That's a skill, just not a useful one.",
    "Your attention span is losing to a goldfish right now. The goldfish is [glow:winning]. By a lot.",
    "You opened this app, felt productive, did nothing, and closed it. Your brain is running the most expensive [strike:scam] on you.",
    "That wasn't a session. That was a [strike:preview]. Nobody builds anything from previews.",
    "The activation energy to start was higher than everything you did after. You burned [heat:jet fuel] to go one metre.",
  ],
  // 5 to 9 minutes.
  from5: [
    "You spent longer heating yesterday's food than you just spent on your [glow:future]. Interesting priorities.",
    "Your phone waited {time}. It survived. You [shake:couldn't].",
    "Under 10 minutes is [ghost:warm-up], not work. You gave it {time}. Not even close.",
    "That's not a session. That's a [strike:false start]. You warmed up and went home.",
    "You paid the full cost of starting and got [ghost:almost nothing] back. Worst return on effort you could pick.",
    "Your future self is watching this and [shake:shaking his head]. He doesn't have words for this.",
    "Even distracted, broken work needs [heat:ten minutes] to mean anything. You gave it {time}. Do the math.",
    "You just interrupted yourself before your brain even knew you'd started. That's not quitting. That's not even [ghost:beginning].",
  ],
  // 10 to 19 minutes.
  from10: [
    "Your brain was just starting to clear the residue from your last distraction. You stopped it mid-process. Now you have to [shake:start over].",
    "You made it past the hardest part (actually starting) and quit before it became a [glow:real session]. That's the move.",
    "Attention takes minutes to come back after a distraction. You got to {time}, turned around, and went back to distracted. [shake:Voluntarily.]",
    "You had a {n}-minute [ghost:warmup] and called it a workout. Gyms would go out of business with that logic.",
    "Here's what you just did: paid the full cost of starting. Collected none of the benefit. Filed for [shake:bankruptcy] on your own time.",
    "The first stretch of a session is the worst. You quit before it got [glow:good]. Brilliant strategy.",
    "{n} minutes is not a session. {n} minutes is the brain warming up. You left the car running and [ghost:never drove anywhere].",
    "Nobody hands out a [glow:real session]. You [heat:earn] it, minute by minute. You stopped at {time}.",
  ],
  // 20 to 29 minutes.
  from20: [
    "You were {left} away from this session actually meaning something. {left}. And you [shake:chose] not to.",
    "The threshold is 45 minutes. You made it to {time} and stopped. That's not a [glow:real session]. That's a [strike:rehearsal].",
    "You spent the hard part of the session (getting into it) and left before the part where [rise:work actually happens]. Genius.",
    "A full {time} of '[strike:I'll just check one thing.]' How'd that work out? Right.",
    "You just handed the dopamine system exactly what it wanted. A quick hit and an exit. It's [shake:laughing at you] right now.",
    "{time} logged, no real session. Your brain's [glow:scorekeeper] isn't fooled.",
    "You got close enough to feel like you tried. That's the worst outcome. You feel okay and the real session [ghost:never happened].",
    "A [glow:real session] is not handed to you. You [heat:earn] it. You stopped {left} short.",
  ],
  // 30 to 44 minutes.
  from30: [
    "You were {left} away. {left}. You've wasted more time deciding what to eat. [heat:Come back] and finish it.",
    "You did the hardest part, {n} full minutes of your brain working, and stopped before it became a [glow:real session]. That's not a strategy. That's [shake:self-sabotage].",
    "{left}. You were {left} from a [glow:real session]. Your phone buzzed once, didn't it.",
    "Past halfway, and you stopped anyway. The threshold doesn't care [ghost:how close you got].",
    "You burned {time} of activation energy and left before collecting the output. [shake:Classic move.]",
    "{time} of your brain at work, and no [glow:real session] to show for it. The threshold is 45.",
    "{time}. {left} [shake:short] of a real session. You'll think about this one. You should.",
    "The dopamine system just convinced you to quit {left} before the [heat:payoff]. It does this every time. You let it, every time.",
  ],
  // 45 to 89 minutes. GO BACK IN is not offered.
  from45: [
    "That counted. A [glow:real session], done. The day isn't wasted. Come back for the next one.",
    "That was real work. Not warmup. Not performance. [heat:Actual output.] Keep [rise:stacking] them.",
    "{time} of focus. Most people won't do that today. [glow:You already did.]",
    "That session counted. The question is whether you stop here or [rise:come back]. Most people stop here.",
    "{time} of focus. You [heat:earned] that. Don't hand it back to a scroll.",
  ],
  // 90 minutes and more. GO BACK IN is not offered.
  from90: [
    "{time} of focus. That's [glow:rare]. Rest properly. Come back.",
    "That wasn't just productivity. That was your brain operating at its [glow:ceiling]. Rest is part of the protocol now.",
    "{time} in [glow:flow]. Most people won't do this once this week. You just did it today.",
    "{time} of your life, actually used. Whatever you built in there is real and it [rise:compounds].",
    "{time} of focus. You [heat:earned] every minute of it. Now go [glow:rest].",
  ],
}

// ---- Choosing a line ----
// Every bank is shown in a shuffled order and no line comes twice before all lines of the bank have been shown (as in the old app). The queue of a bank is the indexes still to show (the next one is the LAST in the list) and the index shown last, so that the first line of a new round is never the line that ended the old round.
export type BankQueue = { rest: readonly number[]; last: number | null }
export type LineQueues = Partial<Record<BankId, BankQueue>>
export type PickedLine = { bank: BankId; index: number; line: string; queues: LineQueues }

// random must give a number from 0 up to, but not including, 1 (Math.random does).
function shuffledIndexes(size: number, random: () => number): number[] {
  const list = Array.from({ length: size }, (_, i) => i)
  for (let i = size - 1; i > 0; i--) {
    const j = Math.min(i, Math.floor(random() * (i + 1)))
    ;[list[i], list[j]] = [list[j], list[i]]
  }
  return list
}

// Picks the line for a session of this length. The queues that come in are not changed; the new ones come back. The line has its slots filled and still has its [effect:words] marks (lineMarkup.ts turns them into pieces).
export function pickStopLine(seconds: number, queues: LineQueues, random: () => number = Math.random): PickedLine {
  const bank = bankIdFor(seconds)
  const lines = STOP_ALERT_BANKS[bank]
  const old = queues[bank] ?? { rest: [], last: null }
  let rest = old.rest
  if (rest.length === 0) {
    const fresh = shuffledIndexes(lines.length, random)
    if (fresh.length > 1 && fresh[fresh.length - 1] === old.last) {
      ;[fresh[0], fresh[fresh.length - 1]] = [fresh[fresh.length - 1], fresh[0]]
    }
    rest = fresh
  }
  const index = rest[rest.length - 1]
  return {
    bank,
    index,
    line: fillSlots(lines[index], seconds),
    queues: { ...queues, [bank]: { rest: rest.slice(0, -1), last: index } },
  }
}
// AB:TIMER.ALERT-LINES:END
```

## STEP 3: Create `src/lib/lineMarkup.test.ts`
Create the file `src/lib/lineMarkup.test.ts` with exactly this content:

```ts
import { describe, expect, it } from "vitest"
import { EFFECTS, fillSlots, minutesText, parseMarkup, plainText, toWords } from "./lineMarkup"
import { GO_BACK_IN_LIMIT_SECONDS } from "./timerMaths"

// AB:TIMER.TESTS:START

// Tests of the marks in the lines of the Pro Timer (slots and effects). Run them with: npm test
// The end of GO BACK IN (45 minutes) that {left} counts to is imported here, not written again, see CONNECTIONS.md C42.

describe("the six effects", () => {
  it("are glow, heat, shake, strike, ghost and rise, in this order (the css of the text component is written for these names)", () => {
    expect([...EFFECTS]).toEqual(["glow", "heat", "shake", "strike", "ghost", "rise"])
  })
})

describe("minutesText", () => {
  it("says minute for 1 and minutes for every other number, 0 included", () => {
    expect(minutesText(1)).toBe("1 minute")
    expect(minutesText(0)).toBe("0 minutes")
    expect(minutesText(2)).toBe("2 minutes")
    expect(minutesText(130)).toBe("130 minutes")
  })
})

describe("fillSlots", () => {
  it("fills {n} with the whole minutes (rounded down) and {time} with the minutes and their unit", () => {
    expect(fillSlots("{n}|{time}", 8 * 60 + 59)).toBe("8|8 minutes")
    expect(fillSlots("{n}|{time}", 60)).toBe("1|1 minute")
    expect(fillSlots("{n}|{time}", 59)).toBe("0|0 minutes")
    expect(fillSlots("{n}|{time}", 130 * 60)).toBe("130|130 minutes")
  })

  it("fills {left} with the minutes still missing to the end of GO BACK IN, rounded UP, never less than 1", () => {
    const limit = GO_BACK_IN_LIMIT_SECONDS
    expect(fillSlots("{left}", limit - 1)).toBe("1 minute")
    expect(fillSlots("{left}", limit - 60)).toBe("1 minute")
    expect(fillSlots("{left}", limit - 61)).toBe("2 minutes")
    expect(fillSlots("{left}", 38 * 60)).toBe("7 minutes")
    expect(fillSlots("{left}", 20 * 60)).toBe("25 minutes")
    expect(fillSlots("{left}", 0)).toBe("45 minutes")
    expect(fillSlots("{left}", limit)).toBe("1 minute")
    expect(fillSlots("{left}", limit * 3)).toBe("1 minute")
  })

  it("fills every slot of a line, also the same slot twice, and leaves the rest of the text alone", () => {
    expect(fillSlots("{left}. You were {left} away, after {time}.", 38 * 60)).toBe("7 minutes. You were 7 minutes away, after 38 minutes.")
    expect(fillSlots("No slot here. {unknown} stays.", 600)).toBe("No slot here. {unknown} stays.")
  })

  it("fills a slot that sits inside a marked word, and does not touch the marks", () => {
    expect(fillSlots("You gave it [heat:{time}].", 8 * 60)).toBe("You gave it [heat:8 minutes].")
  })

  it("counts anything that is not a finite number above 0 as 0 seconds", () => {
    expect(fillSlots("{n}|{left}", Number.NaN)).toBe("0|45 minutes")
    expect(fillSlots("{n}|{left}", -50)).toBe("0|45 minutes")
    expect(fillSlots("{n}|{left}", Number.POSITIVE_INFINITY)).toBe("0|45 minutes")
  })
})

describe("parseMarkup", () => {
  it("gives one plain piece for a line without marks, and nothing for an empty line", () => {
    expect(parseMarkup("Plain line.")).toEqual([{ text: "Plain line.", effect: null }])
    expect(parseMarkup("")).toEqual([])
  })

  it("cuts out a marked piece with its effect, and keeps the plain text around it in order", () => {
    expect(parseMarkup("You [heat:earn] it.")).toEqual([
      { text: "You ", effect: null },
      { text: "earn", effect: "heat" },
      { text: " it.", effect: null },
    ])
  })

  it("reads a mark at the very start, a mark at the very end and two marks next to each other", () => {
    expect(parseMarkup("[glow:Real] work")).toEqual([
      { text: "Real", effect: "glow" },
      { text: " work", effect: null },
    ])
    expect(parseMarkup("Do it [rise:now]")).toEqual([
      { text: "Do it ", effect: null },
      { text: "now", effect: "rise" },
    ])
    expect(parseMarkup("[heat:a][shake:b]")).toEqual([
      { text: "a", effect: "heat" },
      { text: "b", effect: "shake" },
    ])
  })

  it("keeps the words of a marked piece together, spaces, apostrophes and full stops included", () => {
    expect(parseMarkup("A '[strike:I'll just check one thing.]' ok")).toEqual([
      { text: "A '", effect: null },
      { text: "I'll just check one thing.", effect: "strike" },
      { text: "' ok", effect: null },
    ])
  })

  it("never throws: an unknown effect name loses its effect but keeps its text, and a bracket that is not closed stays in the text", () => {
    expect(parseMarkup("A [sparkle:word] here")).toEqual([
      { text: "A ", effect: null },
      { text: "word", effect: null },
      { text: " here", effect: null },
    ])
    expect(parseMarkup("A [heat:word here")).toEqual([{ text: "A [heat:word here", effect: null }])
    expect(parseMarkup("A [heat:] here")).toEqual([{ text: "A [heat:] here", effect: null }])
    expect(parseMarkup("A [Heat:word] here")).toEqual([{ text: "A [Heat:word] here", effect: null }])
  })
})

describe("toWords", () => {
  it("gives no word for an empty line or a line of spaces", () => {
    expect(toWords(parseMarkup(""))).toEqual([])
    expect(toWords(parseMarkup("   "))).toEqual([])
  })

  it("gives one word per word, drops the spaces at the start and the end, and counts several spaces as one", () => {
    const words = toWords(parseMarkup("  one   two three  "))
    expect(words.map((w) => w.map((f) => f.text).join(""))).toEqual(["one", "two", "three"])
  })

  it("puts a marked piece and the text that touches it into ONE word (the word earn with the full stop after it)", () => {
    const words = toWords(parseMarkup("You [heat:earn]. Then [shake:quit]ed it"))
    expect(words).toEqual([
      [{ text: "You", effect: null }],
      [
        { text: "earn", effect: "heat" },
        { text: ".", effect: null },
      ],
      [{ text: "Then", effect: null }],
      [
        { text: "quit", effect: "shake" },
        { text: "ed", effect: null },
      ],
      [{ text: "it", effect: null }],
    ])
  })

  it("gives every word of a marked piece with several words its own word, each with the effect", () => {
    const words = toWords(parseMarkup("a [glow:real session] b"))
    expect(words).toEqual([
      [{ text: "a", effect: null }],
      [{ text: "real", effect: "glow" }],
      [{ text: "session", effect: "glow" }],
      [{ text: "b", effect: null }],
    ])
  })
})

describe("plainText", () => {
  it("is the line without the marks, spaces and punctuation as written", () => {
    expect(plainText("You [heat:earn] it, [glow:real session].")).toBe("You earn it, real session.")
    expect(plainText("")).toBe("")
    expect(plainText("No marks.")).toBe("No marks.")
  })
})
// AB:TIMER.TESTS:END
```

## STEP 4: Create `src/lib/stopAlertLines.test.ts`
Create the file `src/lib/stopAlertLines.test.ts` with exactly this content:

```ts
import { describe, expect, it } from "vitest"
import { EFFECTS, fillSlots, parseMarkup, plainText } from "./lineMarkup"
import {
  BANK_IDS,
  STOP_ALERT_BANKS,
  bankIdFor,
  pickStopLine,
  type BankId,
  type LineQueues,
} from "./stopAlertLines"
import {
  DEEP_FROM_SECONDS,
  FLOW_FROM_SECONDS,
  GO_BACK_IN_LIMIT_SECONDS,
  MIN_SESSION_SECONDS,
  SOLID_FROM_SECONDS,
  canGoBackIn,
} from "./timerMaths"

// AB:TIMER.TESTS:START

// Tests of the stop alert lines and of the choice of one. Run them with: npm test
// The edges of the banks that are cut-offs of the timer are imported here, not written again, see CONNECTIONS.md C41. If a cut-off is changed, the tests of the numbers and words in the lines show which lines to read again.

// The first and the last second of every bank, from the edges (the bank from90 has no last second, 3 hours stands for it).
const EDGES: Record<BankId, readonly [number, number]> = {
  under1: [0, MIN_SESSION_SECONDS - 1],
  from1: [MIN_SESSION_SECONDS, 5 * 60 - 1],
  from5: [5 * 60, SOLID_FROM_SECONDS - 1],
  from10: [SOLID_FROM_SECONDS, 20 * 60 - 1],
  from20: [20 * 60, DEEP_FROM_SECONDS - 1],
  from30: [DEEP_FROM_SECONDS, GO_BACK_IN_LIMIT_SECONDS - 1],
  from45: [GO_BACK_IN_LIMIT_SECONDS, FLOW_FROM_SECONDS - 1],
  from90: [FLOW_FROM_SECONDS, 3 * 3600],
}

// A small fixed series of "random" numbers, so that a test can be repeated exactly.
function seeded(seed: number): () => number {
  let state = seed
  return () => {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0
    return state / 4294967296
  }
}

describe("which bank a session gets", () => {
  it("changes at 60 seconds, 5, 10, 20, 30, 45 and 90 minutes, to the second", () => {
    const at: [number, BankId][] = [
      [0, "under1"],
      [59, "under1"],
      [60, "from1"],
      [299, "from1"],
      [300, "from5"],
      [599, "from5"],
      [600, "from10"],
      [1199, "from10"],
      [1200, "from20"],
      [1799, "from20"],
      [1800, "from30"],
      [2699, "from30"],
      [2700, "from45"],
      [5399, "from45"],
      [5400, "from90"],
      [99999, "from90"],
    ]
    for (const [seconds, bank] of at) expect(bankIdFor(seconds), String(seconds)).toBe(bank)
  })

  it("follows the cut-offs of the timer: 60 seconds is saved, 10 and 30 minutes are the quality steps, 45 minutes ends GO BACK IN, 90 minutes is flow", () => {
    expect(bankIdFor(MIN_SESSION_SECONDS - 1)).toBe("under1")
    expect(bankIdFor(MIN_SESSION_SECONDS)).toBe("from1")
    expect(bankIdFor(SOLID_FROM_SECONDS)).toBe("from10")
    expect(bankIdFor(DEEP_FROM_SECONDS)).toBe("from30")
    expect(bankIdFor(GO_BACK_IN_LIMIT_SECONDS - 1)).toBe("from30")
    expect(bankIdFor(GO_BACK_IN_LIMIT_SECONDS)).toBe("from45")
    expect(bankIdFor(FLOW_FROM_SECONDS - 1)).toBe("from45")
    expect(bankIdFor(FLOW_FROM_SECONDS)).toBe("from90")
  })

  it("gives the bank under1 to anything that is not a finite number above 0", () => {
    expect(bankIdFor(Number.NaN)).toBe("under1")
    expect(bankIdFor(-5)).toBe("under1")
    expect(bankIdFor(Number.POSITIVE_INFINITY)).toBe("under1")
  })

  it("gives the same bank to every second between the edges of the bank, and the edges are the ones of this test file", () => {
    for (const id of BANK_IDS) {
      const [first, last] = EDGES[id]
      expect(bankIdFor(first), id + " first").toBe(id)
      expect(bankIdFor(last), id + " last").toBe(id)
      expect(bankIdFor(Math.floor((first + last) / 2)), id + " middle").toBe(id)
    }
  })

  it("is exactly the banks without GO BACK IN: the banks from45 and from90 are the sessions that cannot go back in", () => {
    for (let s = 0; s <= 6000; s++) {
      const bank = bankIdFor(s)
      expect(canGoBackIn(s), String(s)).toBe(bank !== "from45" && bank !== "from90")
    }
  })
})

describe("the banks", () => {
  it("are the eight banks, in the order of the sessions, and each has at least 4 lines that are not empty and not the same twice", () => {
    expect([...BANK_IDS]).toEqual(["under1", "from1", "from5", "from10", "from20", "from30", "from45", "from90"])
    expect(Object.keys(STOP_ALERT_BANKS).sort()).toEqual([...BANK_IDS].sort())
    for (const id of BANK_IDS) {
      const lines = STOP_ALERT_BANKS[id]
      expect(lines.length, id).toBeGreaterThanOrEqual(4)
      expect(new Set(lines).size, id).toBe(lines.length)
      for (const line of lines) expect(line.trim().length, id).toBeGreaterThan(10)
    }
  })

  it("have no line with a double quote (the lines are written between double quotes in the code)", () => {
    for (const id of BANK_IDS) for (const line of STOP_ALERT_BANKS[id]) expect(line, line).not.toContain('"')
  })
})

describe("the marks in the lines", () => {
  const all: [BankId, string][] = BANK_IDS.flatMap((id) => STOP_ALERT_BANKS[id].map((line): [BankId, string] => [id, line]))

  it("use only the six known effect names, and every effect mark is closed", () => {
    for (const [id, line] of all) {
      for (const m of line.matchAll(/\[([^\]:]*):/g)) expect((EFFECTS as readonly string[]).includes(m[1]), id + ": " + line).toBe(true)
      expect((line.match(/\[/g) ?? []).length, line).toBe((line.match(/\]/g) ?? []).length)
    }
  })

  it("give every line one to three marked keywords", () => {
    for (const [id, line] of all) {
      const marked = parseMarkup(line).filter((f) => f.effect !== null).length
      expect(marked, id + ": " + line).toBeGreaterThanOrEqual(1)
      expect(marked, id + ": " + line).toBeLessThanOrEqual(3)
    }
  })

  it("leave no slot and no bracket in the text when the slots are filled, at the first and at the last second of the bank", () => {
    for (const id of BANK_IDS) {
      for (const seconds of EDGES[id]) {
        for (const line of STOP_ALERT_BANKS[id]) {
          const text = plainText(fillSlots(line, seconds))
          expect(text, id + " " + seconds + ": " + line).not.toMatch(/[{}[\]]/)
        }
      }
    }
  })

  it("never say 0 minutes or 1 minutes (the unit must agree with the number) when the slots are filled, at the edges of every bank", () => {
    for (const id of BANK_IDS) {
      for (const seconds of EDGES[id]) {
        for (const line of STOP_ALERT_BANKS[id]) {
          const text = plainText(fillSlots(line, seconds))
          expect(text, id + " " + seconds + ": " + line).not.toMatch(/\b1 minutes\b/)
          if (id !== "under1") expect(text, id + " " + seconds + ": " + line).not.toMatch(/\b0 minutes\b/)
        }
      }
    }
  })

  it("use {left} only in the banks of sessions shorter than 45 minutes, and no slot at all in the bank of sessions that were not saved", () => {
    for (const id of BANK_IDS) {
      for (const line of STOP_ALERT_BANKS[id]) {
        if (id === "from45" || id === "from90" || id === "under1") expect(line, id + ": " + line).not.toContain("{left}")
        if (id === "under1") expect(line, id + ": " + line).not.toMatch(/\{(n|time)\}/)
      }
    }
  })
})

describe("the numbers and words written in the lines", () => {
  // A number written in a line is a cut-off of the timer and is true for the bank it sits in: 10 minutes (the first quality step) in the bank from5, 45 minutes (the end of GO BACK IN) in the banks from20 and from30. The numbers come from the imported cut-offs, so if a cut-off is changed this test names the lines to read again (C41).
  const ALLOWED: Partial<Record<BankId, string[]>> = {
    from5: [String(SOLID_FROM_SECONDS / 60)],
    from20: [String(GO_BACK_IN_LIMIT_SECONDS / 60)],
    from30: [String(GO_BACK_IN_LIMIT_SECONDS / 60)],
  }

  it("allow a number only where it is a cut-off that is true for the bank", () => {
    for (const id of BANK_IDS) {
      for (const line of STOP_ALERT_BANKS[id]) {
        for (const m of plainText(line).matchAll(/\d+/g)) {
          expect(ALLOWED[id] ?? [], id + ": " + line).toContain(m[0])
        }
      }
    }
  })

  it("say flow only from 90 minutes (the flow of the timer starts there), and not solid or deep, which are quality words of the timer with other cut-offs", () => {
    for (const id of BANK_IDS) {
      for (const line of STOP_ALERT_BANKS[id]) {
        const text = plainText(line)
        if (id !== "from90") expect(text, id + ": " + line).not.toMatch(/\bflow\b/i)
        expect(text, id + ": " + line).not.toMatch(/\b(solid|deep)\b/i)
      }
    }
  })

  it("never say what the app cannot know or what is false for a saved session: the time of day, earlier sessions, unbroken, zero, counted for nothing", () => {
    const banned = [
      "unbroken",
      "morning",
      "lunch",
      "afternoon",
      "evening",
      "first real session",
      "one session",
      "two more",
      "zero",
      "counted for nothing",
      "counts as zero",
      "nothing got done",
    ]
    for (const id of BANK_IDS) {
      for (const line of STOP_ALERT_BANKS[id]) {
        const text = plainText(line).toLowerCase()
        for (const phrase of banned) expect(text, id + ": " + line).not.toContain(phrase)
      }
    }
  })
})

describe("pickStopLine", () => {
  it("picks a line of the bank of the session, with its slots filled and its effect marks still in it", () => {
    const picked = pickStopLine(38 * 60, {}, seeded(1))
    expect(picked.bank).toBe("from30")
    expect(STOP_ALERT_BANKS.from30[picked.index]).toBeDefined()
    expect(picked.line).toBe(fillSlots(STOP_ALERT_BANKS.from30[picked.index], 38 * 60))
    expect(picked.line).not.toMatch(/[{}]/)
  })

  it("shows every line of a bank once before any line comes twice, and the queue of the bank is then empty", () => {
    const size = STOP_ALERT_BANKS.from10.length
    let queues: LineQueues = {}
    const seen: number[] = []
    const random = seeded(7)
    for (let i = 0; i < size; i++) {
      const picked = pickStopLine(12 * 60, queues, random)
      seen.push(picked.index)
      queues = picked.queues
    }
    expect([...seen].sort((a, b) => a - b)).toEqual(Array.from({ length: size }, (_, i) => i))
    expect(queues.from10?.rest).toEqual([])
  })

  it("never starts a new round with the line that ended the old round, for many different series of random numbers", () => {
    for (let seed = 1; seed <= 200; seed++) {
      const size = STOP_ALERT_BANKS.from45.length
      const random = seeded(seed)
      let queues: LineQueues = {}
      let previous = -1
      for (let i = 0; i < size * 4; i++) {
        const picked = pickStopLine(50 * 60, queues, random)
        expect(picked.index, "seed " + seed + " pick " + i).not.toBe(previous)
        previous = picked.index
        queues = picked.queues
      }
    }
  })

  it("keeps a queue for each bank, so a session of another length does not use up the lines of the first", () => {
    const first = pickStopLine(12 * 60, {}, seeded(3))
    const other = pickStopLine(50 * 60, first.queues, seeded(4))
    expect(other.queues.from10).toEqual(first.queues.from10)
    expect(other.queues.from45?.last).toBe(other.index)
    expect(other.bank).toBe("from45")
  })

  it("does not change the queues that come in", () => {
    const queues: LineQueues = { from5: { rest: [2, 0, 1], last: 3 } }
    const copy = JSON.parse(JSON.stringify(queues))
    const picked = pickStopLine(6 * 60, queues, seeded(5))
    expect(queues).toEqual(copy)
    expect(picked.index).toBe(1)
    expect(picked.queues.from5).toEqual({ rest: [2, 0], last: 1 })
  })

  it("works with a random number of exactly 0 and of just under 1, and with the default random number", () => {
    for (const value of [0, 0.999999999]) {
      let queues: LineQueues = {}
      const size = STOP_ALERT_BANKS.under1.length
      const seen = new Set<number>()
      for (let i = 0; i < size; i++) {
        const picked = pickStopLine(10, queues, () => value)
        seen.add(picked.index)
        queues = picked.queues
      }
      expect(seen.size).toBe(size)
    }
    expect(typeof pickStopLine(130 * 60, {}).line).toBe("string")
  })
})
// AB:TIMER.TESTS:END
```

## STEP 5: Check that the four files are exactly right
Run this ONE command (it prints one line per file: the path and a fingerprint of the file with line endings and trailing blank lines ignored):
```
foreach ($f in @("src/lib/lineMarkup.ts","src/lib/stopAlertLines.ts","src/lib/lineMarkup.test.ts","src/lib/stopAlertLines.test.ts")) { $t = (Get-Content -Raw -Encoding UTF8 $f).Replace("`r`n","`n").TrimEnd(); $h = [System.BitConverter]::ToString([System.Security.Cryptography.SHA256]::Create().ComputeHash([System.Text.Encoding]::UTF8.GetBytes($t))).Replace("-","").ToLower(); "$f $h" }
```
It must print exactly these four lines:
```
src/lib/lineMarkup.ts 4320574c170ef64ba120b8a0584384c80c115bab39bb562bb52784d283aff743
src/lib/stopAlertLines.ts a3894ab1d00776ec790c2cc309f258e3f96e33fb89be411e2fa8455919e01b7b
src/lib/lineMarkup.test.ts f99ff83631e12c5f6f9464377f925ef7bcebe8a7e6cbfb77e0047c70cbb6b2ef
src/lib/stopAlertLines.test.ts f46ed20874f93f1d892ce5aa943f5b9448985bfaa9e49e42e27e934d941c60e0
```
If a fingerprint is different, or the command fails: **STOP** and report the RAW output and, for the files that differ, the output of `(Get-Content <path>).Count`. Do not fix the file. (Expected line counts: `src/lib/lineMarkup.ts` 86, `src/lib/stopAlertLines.ts` 160, `src/lib/lineMarkup.test.ts` 156, `src/lib/stopAlertLines.test.ts` 293.)

## STEP 6: Run the tests and the type check
Run:
```
npm test
```
It must finish with a line `Test Files  12 passed (12)` and a line `Tests  603 passed (603)` (565 from before, plus 17 and 21 new tests). It runs once and stops by itself. If any test fails or the count is different: **STOP** and report the COMPLETE output. Do not edit any file. Copy the last 12 lines of the output.

Run:
```
npx tsc -b
```
It must print nothing. If it prints anything: **STOP** and report the COMPLETE output.

## STEP 7: Edit `CODE_MAP.md`, `CONNECTIONS.md` and `PROGRESS.md`
Change nothing else in these files.

**`CODE_MAP.md`: one row replaced, two rows added.** Both texts below must be found EXACTLY ONCE.

Row 1 of 2. Replace this whole line:
```
| `AB:TIMER.TESTS` | The automated tests of the Pro Timer: the maths, the database calls, the live state, the screen, the glowing ball and its look, the moving background and its look, and the choice of screen in the signed-in stub. Run them with npm test | `src/lib/timerMaths.test.ts`, `src/lib/timerApi.test.ts`, `src/lib/useTimer.test.ts`, `src/lib/useTimer.hook.test.ts`, `src/components/TimerScreen.test.tsx`, `src/components/TimerBall.test.tsx`, `src/components/SignedInStub.test.tsx`, `src/lib/ballLook.test.ts`, `src/components/TimerBackground.test.tsx`, `src/lib/backgroundLook.test.ts` | add tests; the numbers and names written in them must match the code, see CONNECTIONS.md C27, C28, C29, C33, C34, C35, C37 and C38 |
```
with this whole line:
```
| `AB:TIMER.TESTS` | The automated tests of the Pro Timer: the maths, the database calls, the live state, the screen, the glowing ball and its look, the moving background and its look, the choice of screen in the signed-in stub, and the lines of the stop alert with their marks. Run them with npm test | `src/lib/timerMaths.test.ts`, `src/lib/timerApi.test.ts`, `src/lib/useTimer.test.ts`, `src/lib/useTimer.hook.test.ts`, `src/components/TimerScreen.test.tsx`, `src/components/TimerBall.test.tsx`, `src/components/SignedInStub.test.tsx`, `src/lib/ballLook.test.ts`, `src/components/TimerBackground.test.tsx`, `src/lib/backgroundLook.test.ts`, `src/lib/lineMarkup.test.ts`, `src/lib/stopAlertLines.test.ts` | add tests; the numbers and names written in them must match the code, see CONNECTIONS.md C27, C28, C29, C33, C34, C35, C37, C38, C41 and C42 |
```

Row 2 of 2. Find the line that starts with `| `AB:TIMER.BG` |` (the row of the moving background; the row `AB:TIMER.BG-LOOK` is a different row and does not count). Directly after that line, and before the row `AB:TIMER.TESTS`, add these two new lines, in this order:
```
| `AB:TIMER.LINE-MARKUP` | How a line of text of the Pro Timer is written and cut into pieces: the slots {n}, {time} and {left}, which are filled with the real numbers of the session, the effect marks [effect:words] with the six effect names, and the cutting of a line into words for the screen | `src/lib/lineMarkup.ts` | the six effect names (EFFECTS: the css of the text component that shows the lines is written for these names), the marks and the slots, and how {left} counts, see CONNECTIONS.md C42 |
| `AB:TIMER.ALERT-LINES` | The lines of the stop alert (the text shown after Hold to end session) in eight banks by the length of the session, with the keywords of each line marked for an effect, and the choice of one line (shuffled, no line twice before all were shown) | `src/lib/stopAlertLines.ts` | the lines and their marked keywords (every line keeps one to three marked keywords and follows the rules in the comment of the tag); the edges of the banks follow the cut-offs of the timer, see CONNECTIONS.md C41 |
```

**`CONNECTIONS.md`: one sentence added to C27, and two new entries C41 and C42.**

Change 1 of 2. Inside the entry C27 (the heading line starts with `### C27:`) find this text:
```text
The neon colours and the first ring colour are safe to tune alone and are not pinned.
```
and replace it with:
```text
The neon colours and the first ring colour are safe to tune alone and are not pinned. The numbers and words in the lines of the stop alert follow these cut-offs too (C41).
```

Change 2 of 2. Find the line `## Things to know (no check is possible)` (it must be found EXACTLY ONCE). Directly BEFORE that line, add the following two entries, with one empty line between them and one empty line after the second one (so that an empty line stands between the last line of C42 and the line `## Things to know (no check is possible)`). The entry C40 stays exactly as it is, right above them.

```text
### C41: The lines of the stop alert are tied to the cut-offs of the timer (the edges of the banks, the numbers written in the lines, the words flow, solid and deep) and to the GO BACK IN rule
- Tags: `AB:TIMER.ALERT-LINES`, `AB:TIMER.LINE-MARKUP`, `AB:TIMER.MATHS`, `AB:TIMER.TESTS`
- If you change: a cut-off in timerMaths.ts (MIN_SESSION_SECONDS, SOLID_FROM_SECONDS, DEEP_FROM_SECONDS, GO_BACK_IN_LIMIT_SECONDS or FLOW_FROM_SECONDS), the edges or the names of the banks in stopAlertLines.ts, the number or the words in a line (a number, flow, solid, deep), or which sessions are offered GO BACK IN
- Then also: the banks are named by their minutes (from1, from5, from10, from20, from30, from45, from90, and under1 for a session under 60 seconds that is not saved). Five edges are cut-offs of the timer and are imported, not written again: 60 seconds (from1), 10 minutes (from10, the first quality step), 30 minutes (from30, the second quality step), 45 minutes (from45, the end of GO BACK IN) and 90 minutes (from90, flow). The edges 5 and 20 minutes (from5 and from20) belong to the banks only. A number written in a line is a cut-off that is true for the bank it sits in: 10 in the bank from5 ("Under 10 minutes", and the word ten), 45 in the banks from20 and from30 ("The threshold is 45"). The word flow is only said from 90 minutes. The words solid and deep are never used, because the quality words of the timer start at other minutes than the banks. {left} counts the minutes to 45 (GO_BACK_IN_LIMIT_SECONDS, see C42) and is only used under 45 minutes. If a cut-off is changed, the tests of stopAlertLines.test.ts fail and name the line to read again. The banks from45 and from90 are exactly the sessions that are not offered GO BACK IN (a test goes through every second up to 100 minutes). The screen of the stop alert (a later packet) takes its bank from bankIdFor and its GO BACK IN button from canGoBackIn: the two must never disagree.
- If you forget: a line tells the person a number or a word that is false for the session on the screen (for example 45 minutes in a bank of 50-minute sessions, or flow at 40 minutes), or the alert offers GO BACK IN with a line that says the session is over.
- Anchor: `AB:TIMER.ALERT-LINES @ src/lib/stopAlertLines.ts = ["from90", FLOW_FROM_SECONDS],`
- Anchor: `AB:TIMER.ALERT-LINES @ src/lib/stopAlertLines.ts = ["from45", GO_BACK_IN_LIMIT_SECONDS],`
- Anchor: `AB:TIMER.ALERT-LINES @ src/lib/stopAlertLines.ts = ["from30", DEEP_FROM_SECONDS],`
- Anchor: `AB:TIMER.ALERT-LINES @ src/lib/stopAlertLines.ts = ["from10", SOLID_FROM_SECONDS],`
- Anchor: `AB:TIMER.ALERT-LINES @ src/lib/stopAlertLines.ts = ["from1", MIN_SESSION_SECONDS],`
- Anchor: `AB:TIMER.ALERT-LINES @ src/lib/stopAlertLines.ts = return "under1"`
- Anchor: `AB:TIMER.TESTS @ src/lib/stopAlertLines.test.ts = describe("which bank a session gets", () => {`
- Anchor: `AB:TIMER.TESTS @ src/lib/stopAlertLines.test.ts = describe("the numbers and words written in the lines", () => {`
- Check by hand: when a cut-off of the timer changes, read the lines of the banks around it in stopAlertLines.ts. The tests stop the build when a written number or word is no longer true, but they cannot judge the meaning of a sentence (for example "Past halfway" in the bank from30).

### C42: The marks in a line ({n}, {time}, {left} and [effect:words]) are read by one function, and the six effect names are the names the text component of the screen has to draw
- Tags: `AB:TIMER.LINE-MARKUP`, `AB:TIMER.ALERT-LINES`, `AB:TIMER.TESTS`
- If you change: the six effect names (EFFECTS in lineMarkup.ts), the form of a mark (the square brackets and the colon, MARK in lineMarkup.ts), the slots ({n}, {time}, {left}) or how {left} counts, or the marks written in a line of stopAlertLines.ts
- Then also: a line is plain text with two kinds of marks. {n}, {time} and {left} are filled by fillSlots BEFORE the line is cut up, so a slot can sit inside a marked word ("[heat:{time}]"). [effect:words] marks the words that get an effect; the effect name is one of the six names in EFFECTS (glow, heat, shake, strike, ghost, rise), lower case, followed by a colon. parseMarkup never throws: an unknown effect name loses its effect and keeps its text, a bracket that is not closed stays in the text, so a typo shows on the screen instead of breaking the alert; the tests of stopAlertLines.test.ts read every line and fail on an unknown name or an unclosed bracket. {left} is the minutes still missing to GO_BACK_IN_LIMIT_SECONDS (45 minutes), rounded UP and never less than 1; it is tied to the same cut-off as the banks (C41). The css and the text component that DRAW the six effects come in a later packet: that packet must give each of the six names a rule, and must then extend this entry with its own anchors, because a new name in EFFECTS without a rule in the css would show a keyword with no effect, and a rule in the css without a name in EFFECTS would never be used.
- If you forget: a keyword shows no effect, or the brackets and the colon show as text on the screen, or a number in a line is wrong (a slot not filled, "1 minutes", or {left} that counts to another minute than the one where GO BACK IN stops).
- Anchor: `AB:TIMER.LINE-MARKUP @ src/lib/lineMarkup.ts = export const EFFECTS = ["glow", "heat", "shake", "strike", "ghost", "rise"] as const`
- Anchor: `AB:TIMER.LINE-MARKUP @ src/lib/lineMarkup.ts = const MARK = /\[([a-z]+):([^[\]]+)\]/g`
- Anchor: `AB:TIMER.LINE-MARKUP @ src/lib/lineMarkup.ts = const left = Math.max(1, Math.ceil((GO_BACK_IN_LIMIT_SECONDS - s) / 60))`
- Anchor: `AB:TIMER.TESTS @ src/lib/lineMarkup.test.ts = describe("the six effects", () => {`
- Anchor: `AB:TIMER.TESTS @ src/lib/stopAlertLines.test.ts = describe("the marks in the lines", () => {`
- Check by hand: open src/lib/stopAlertLines.ts and read three lines: every marked keyword is written [name:words] with one of the six names, and the sentence still reads well with the marks taken away.
```

**`PROGRESS.md`: one line.** Find the line that starts with `- Packet 05E2:` (it must be found EXACTLY ONCE; if it is found zero times or more than once: **STOP** and report). Directly after that line, add this new line:
```
- Packet 05F0: the lines of the stop alert (the text shown after Hold to end session): 53 lines in eight banks by the length of the session (under 60 seconds, 1, 5, 10, 20, 30, 45 and 90 minutes), written for the real numbers of the session ({n}, {time} and {left} are filled from the seconds) and with the keywords of each line marked for an effect ([effect:words], six effects: glow, heat, shake, strike, ghost, rise). The choice of a line is shuffled, with no line twice before all were shown. The edges of the banks follow the cut-offs of the timer (src/lib/timerMaths.ts). No screen change: nothing uses the lines yet; the alert itself and the text effects come in the next packets. With automated tests.
```

## STEP 8: Check the checker, the build and the changed files
Run:
```
node scripts/check-tags.mjs
```
It must print exactly:
```
TAGS OK: 28 tags, 50 places
CONNECTIONS OK: 42 connections, 249 anchors, 36 classes, 2 css variables, 2 label links
```
If it prints anything else: **STOP** and report the COMPLETE output. Do not fix it.

Run:
```
npm run build
```
It must finish with no errors. (A warning that some chunks are larger than 500 kB is expected and harmless.) If it fails: **STOP** and report the COMPLETE output.

Run these two and copy the RAW output of each:
1. `git diff --stat`
2. `git status --short`

`git diff --stat` must list exactly `CODE_MAP.md`, `CONNECTIONS.md` and `PROGRESS.md`, and it may also list the two files named in the rules (they had changes before this packet). The four new files show in `git status --short` as `??` lines. If ANY other tracked file is listed (for example `package.json`, `package-lock.json` or any file in `src/components`): **STOP** and report the COMPLETE output. Do not commit.

## STEP 9: Check that no secret file is tracked, then commit
Run:
```
git ls-files | Select-String -Pattern "\.env"
```
It must print NOTHING. If it prints any line: **STOP** and report it. Do not commit and do not push.

Then run these two lines, exactly as written. Do NOT use `git add .`:
```
git add src/lib/lineMarkup.ts src/lib/stopAlertLines.ts src/lib/lineMarkup.test.ts src/lib/stopAlertLines.test.ts CODE_MAP.md CONNECTIONS.md PROGRESS.md
git commit -m "Packet 05F0: the lines of the stop alert with keyword marks and the choice of a line (no screen change)"
```
(Line-ending warnings from git are harmless. Ignore them.)
Then run `git show --stat HEAD` and copy its exact output. Then run `git status --short` and copy its raw output. The two files named in the rules and untracked files may still show: leave them alone.

## STEP 10: Push
Run:
```
git push
```
If `git push` fails, asks for a login, or says there is no upstream branch: **STOP** and report the COMPLETE output (the commit stays; nothing is lost). Do not try another push command.
Then run `git status -sb` and copy its first line.

---

## DONE-CHECKS (all must pass)
1. At the start, `node scripts/check-tags.mjs` printed the two lines of Step 0, `npm test` printed `Tests  565 passed (565)`, the seven lines of `timerMaths.ts` matched, and the four new files did not exist.
2. The four fingerprint lines of Step 5 matched exactly.
3. `npm test` printed `Test Files  12 passed (12)` and `Tests  603 passed (603)`, and `npx tsc -b` printed nothing.
4. `node scripts/check-tags.mjs` printed the two lines of Step 8 (28 tags, 50 places; 42 connections, 249 anchors).
5. `npm run build` finished with no errors.
6. `git show --stat HEAD` lists exactly these 7 files: `src/lib/lineMarkup.ts`, `src/lib/stopAlertLines.ts`, `src/lib/lineMarkup.test.ts`, `src/lib/stopAlertLines.test.ts`, `CODE_MAP.md`, `CONNECTIONS.md`, `PROGRESS.md`.
7. The first line of `git log --oneline` ends with `Packet 05F0: the lines of the stop alert with keyword marks and the choice of a line (no screen change)`.
8. `git ls-files | Select-String -Pattern "\.env"` prints nothing.
9. `git push` finished without an error.
10. No file other than the ones named in this packet was created, edited or committed, and NO helper script or temp file was created at any time (also not one that was deleted afterwards). No file in `src/components`, no css file and no hook was changed.

## WHEN DONE
Reply with the raw outputs below, not only PASS or FAIL:
- PASS or FAIL for each of the 10 done-checks. If you had to create a helper file, say so and mark check 10 FAIL.
- the RAW outputs of the 5 read-only commands of Step 0, the output of `node scripts/check-tags.mjs` of Step 0, the last 3 lines of the `npm test` of Step 0, and the 7 lines of the `timerMaths.ts` command
- the exact four lines printed in Step 5
- the last 12 lines of the output of `npm test` (Step 6), and the output of `npx tsc -b` (or the word EMPTY)
- the exact output of `node scripts/check-tags.mjs` from Step 8
- the last 5 lines of the output of `npm run build`
- the RAW outputs of `git diff --stat` and `git status --short` from Step 8
- the RAW output of `git ls-files | Select-String -Pattern "\.env"`, the exact output of `git show --stat HEAD` and of `git status --short` from Step 9
- the exact output of `git log --oneline -3`
- the exact output of `git push`, and the first line of `git status -sb`
- any warning messages, copied exactly

Do not suggest next steps. Do not start another packet. The owner will look at the result himself.

---

## HOW TO UNDO (not the agent's job)
The whole packet is one commit, so one `git revert <hash of the commit of Step 9>` in the planner chat removes the four files and the three map edits. Nothing else in the app depends on them yet.

## THE OWNER'S OWN LOOK (not the agent's job; after the push)
Nothing changes on the screen, and that is the test.
1. Open `#timer` on the laptop and on the phone. Start, Pause, Resume, hold to end: everything works and looks exactly as after Packet 05E2. If anything looks or behaves differently, tell the planner (it should be impossible: nothing imports the new files).
2. Read the lines in the file `LINES_05F0_FOR_APPROVAL.md` that comes with this packet. For each line you can say: keep, change the words, drop. And for each marked keyword: is it the right word to light up, and is it the right effect (glow, heat, shake, strike, ghost, rise)? The lines are cheap to change now and a little more work after the alert exists.
3. The six effect names are the names the next text component has to draw. If you want a seventh kind of effect, say so before that packet is written.
