# Packet 05F0: the 53 stop-alert lines, for your approval

These are the exact lines in the packet. Nothing is visible in the app yet. Tell me, per line: **keep**, **change the words**, or **drop**. And for the marked words: is it the right word to light up, and the right effect?

## How to read a line

- `{n}` = whole minutes of the session (8 for 8 min 59 s). `{time}` = the same with the unit ("8 minutes", "1 minute"). `{left}` = minutes still missing to 45, rounded up (a 38-minute session shows "7 minutes").
- `[effect:words]` = the words that get an effect when the line appears. The six effects:

| Effect | Meant for | Example in the lines |
|---|---|---|
| `glow` | the true or important thing | a **[glow:real session]**, **[glow:rare]**, **[glow:rest]** |
| `heat` | effort, earning, going back | you **[heat:earn]** it, **[heat:Go back in]**, **[heat:payoff]** |
| `shake` | failure, flinching | **[shake:lost your nerve]**, **[shake:self-sabotage]** |
| `strike` | the fake thing | **[strike:cosplay]**, **[strike:rehearsal]**, **[strike:scam]** |
| `ghost` | nothing, fading away | **[ghost:remember it]**, **[ghost:never happened]** |
| `rise` | growing, stacking | **[rise:stacking]**, **[rise:compounds]**, **[rise:come back]** |

How often each effect is used in the 53 lines: glow 17, heat 11, shake 14, strike 6, ghost 9, rise 4.

The word *earn* in your example ("earn REAL") is in bank 10 to 19 and bank 20 to 29: `You [heat:earn] it` and `a [glow:real session]` in the same line, so both words light up with different effects.

## Under 60 seconds (not saved; GO BACK IN is offered): 4 lines

1. Under a minute, so nothing was saved. That wasn't a session. That was a [shake:tap].
2. Not even one minute. The timer won't save it, and your future self won't [ghost:remember it].
3. A minute is the minimum. You didn't reach it. [heat:Go back in], or admit you only came to look.
4. Nothing to save. You pressed start and [shake:lost your nerve]. [heat:Go back in] and make it count.

## 1 to 4 minutes (GO BACK IN is offered): 7 lines

1. You sat down, opened the timer, felt like you did something, and left. That's not work. That's [strike:cosplay].
2. A [shake:microwave] runs longer than your [ghost:focus span] just did. Think about that.
3. You spent more time [shake:deciding] to start than you spent actually working. That's a skill, just not a useful one.
4. Your attention span is losing to a goldfish right now. The goldfish is [glow:winning]. By a lot.
5. You opened this app, felt productive, did nothing, and closed it. Your brain is running the most expensive [strike:scam] on you.
6. That wasn't a session. That was a [strike:preview]. Nobody builds anything from previews.
7. The activation energy to start was higher than everything you did after. You burned [heat:jet fuel] to go one metre.

## 5 to 9 minutes (GO BACK IN is offered): 8 lines

1. You spent longer heating yesterday's food than you just spent on your [glow:future]. Interesting priorities.
2. Your phone waited {time}. It survived. You [shake:couldn't].
3. Under 10 minutes is [ghost:warm-up], not work. You gave it {time}. Not even close.
4. That's not a session. That's a [strike:false start]. You warmed up and went home.
5. You paid the full cost of starting and got [ghost:almost nothing] back. Worst return on effort you could pick.
6. Your future self is watching this and [shake:shaking his head]. He doesn't have words for this.
7. Even distracted, broken work needs [heat:ten minutes] to mean anything. You gave it {time}. Do the math.
8. You just interrupted yourself before your brain even knew you'd started. That's not quitting. That's not even [ghost:beginning].

## 10 to 19 minutes (GO BACK IN is offered): 8 lines

1. Your brain was just starting to clear the residue from your last distraction. You stopped it mid-process. Now you have to [shake:start over].
2. You made it past the hardest part (actually starting) and quit before it became a [glow:real session]. That's the move.
3. Attention takes minutes to come back after a distraction. You got to {time}, turned around, and went back to distracted. [shake:Voluntarily.]
4. You had a {n}-minute [ghost:warmup] and called it a workout. Gyms would go out of business with that logic.
5. Here's what you just did: paid the full cost of starting. Collected none of the benefit. Filed for [shake:bankruptcy] on your own time.
6. The first stretch of a session is the worst. You quit before it got [glow:good]. Brilliant strategy.
7. {n} minutes is not a session. {n} minutes is the brain warming up. You left the car running and [ghost:never drove anywhere].
8. Nobody hands out a [glow:real session]. You [heat:earn] it, minute by minute. You stopped at {time}.

## 20 to 29 minutes (GO BACK IN is offered): 8 lines

1. You were {left} away from this session actually meaning something. {left}. And you [shake:chose] not to.
2. The threshold is 45 minutes. You made it to {time} and stopped. That's not a [glow:real session]. That's a [strike:rehearsal].
3. You spent the hard part of the session (getting into it) and left before the part where [rise:work actually happens]. Genius.
4. A full {time} of '[strike:I'll just check one thing.]' How'd that work out? Right.
5. You just handed the dopamine system exactly what it wanted. A quick hit and an exit. It's [shake:laughing at you] right now.
6. {time} logged, no real session. Your brain's [glow:scorekeeper] isn't fooled.
7. You got close enough to feel like you tried. That's the worst outcome. You feel okay and the real session [ghost:never happened].
8. A [glow:real session] is not handed to you. You [heat:earn] it. You stopped {left} short.

## 30 to 44 minutes (GO BACK IN is offered): 8 lines

1. You were {left} away. {left}. You've wasted more time deciding what to eat. [heat:Come back] and finish it.
2. You did the hardest part, {n} full minutes of your brain working, and stopped before it became a [glow:real session]. That's not a strategy. That's [shake:self-sabotage].
3. {left}. You were {left} from a [glow:real session]. Your phone buzzed once, didn't it.
4. Past halfway, and you stopped anyway. The threshold doesn't care [ghost:how close you got].
5. You burned {time} of activation energy and left before collecting the output. [shake:Classic move.]
6. {time} of your brain at work, and no [glow:real session] to show for it. The threshold is 45.
7. {time}. {left} [shake:short] of a real session. You'll think about this one. You should.
8. The dopamine system just convinced you to quit {left} before the [heat:payoff]. It does this every time. You let it, every time.

## 45 to 89 minutes (no GO BACK IN): 5 lines

1. That counted. A [glow:real session], done. The day isn't wasted. Come back for the next one.
2. That was real work. Not warmup. Not performance. [heat:Actual output.] Keep [rise:stacking] them.
3. {time} of focus. Most people won't do that today. [glow:You already did.]
4. That session counted. The question is whether you stop here or [rise:come back]. Most people stop here.
5. {time} of focus. You [heat:earned] that. Don't hand it back to a scroll.

## 90 minutes and more (no GO BACK IN): 5 lines

1. {time} of focus. That's [glow:rare]. Rest properly. Come back.
2. That wasn't just productivity. That was your brain operating at its [glow:ceiling]. Rest is part of the protocol now.
3. {time} in [glow:flow]. Most people won't do this once this week. You just did it today.
4. {time} of your life, actually used. Whatever you built in there is real and it [rise:compounds].
5. {time} of focus. You [heat:earned] every minute of it. Now go [glow:rest].

## Rules every line follows (the tests check them)

- A number written in a line is a real cut-off for its bank (10 minutes in the 5 to 9 bank, 45 in the 20 to 29 and 30 to 44 banks). All other numbers are the `{n}`, `{time}` and `{left}` slots.
- The word "flow" only appears from 90 minutes. The words "solid" and "deep" never appear (the timer uses them with other minutes).
- No line says the time of day, how many sessions came before, "unbroken", or that a saved session counted for nothing.
- Every line has one to three marked words.
- Lines that kept a science-sounding claim from the old app ("dopamine system" in two lines, "your brain's scorekeeper"): kept because your review defaults said only the McKinsey, "phone was silent" and the loosest brain claims go. Tell me if you want them out.
